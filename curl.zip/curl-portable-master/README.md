# curl-portable
A portable version of CURL for Windows.
